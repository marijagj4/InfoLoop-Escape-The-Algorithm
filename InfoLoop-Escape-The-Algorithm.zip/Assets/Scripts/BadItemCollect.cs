using UnityEngine;

public class BadItemCollect : MonoBehaviour
{
    public int trapAmount = 1;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            GameManager gameManager = FindFirstObjectByType<GameManager>();
            SoundManager soundManager = FindFirstObjectByType<SoundManager>();
            CardLabel cardLabel = GetComponent<CardLabel>();

            string label = "";

            if (cardLabel != null)
            {
                label = cardLabel.currentLabel;
            }

            if (soundManager != null)
            {
                soundManager.PlayBadSound();
            }
            else
            {
                Debug.LogWarning("SoundManager not found!");
            }

            if (gameManager != null)
            {
                if (label.Contains("Emotional") || label.Contains("One-sided") || label.Contains("Sponsored"))
                {
                    gameManager.AddBias(1);
                    Debug.Log("Bad bias card collected: " + label);
                }
                else if (label.Contains("AI Fake"))
                {
                    gameManager.AddTrap(2);
                    Debug.Log("AI Fake Image collected: +2 Algorithm Trap");
                }
                else
                {
                    gameManager.AddTrap(trapAmount);
                    Debug.Log("Bad card collected: " + label);
                }
            }

            Destroy(gameObject);
        }
    }
}