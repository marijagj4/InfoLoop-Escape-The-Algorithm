using UnityEngine;

public class ItemSpawner : MonoBehaviour
{
    public GameObject goodItemPrefab;
    public GameObject badItemPrefab;

    public float spawnInterval = 1.4f;
    public float minX = -7f;
    public float maxX = 7f;
    public float spawnY = 4.5f;

    private float timer = 0f;
    private int currentLevel = 1;

    private string[] goodLevel1 =
    {
        "Verified\nSource",
        "Fact\nCheck",
        "Date\nChecked"
    };

    private string[] badLevel1 =
    {
        "Clickbait\nTrap",
        "Fake\nNews",
        "No\nDate"
    };

    private string[] goodLevel2 =
    {
        "Author\nFound",
        "Compare\nSources",
        "Analyze\nMessage",
        "Double\nCheck"
    };

    private string[] badLevel2 =
    {
        "Unknown\nSource",
        "No\nAuthor",
        "Viral\nNot True",
        "Emotional\nManipulation",
        "One-sided\nStory",
        "Sponsored\nContent"
    };

    private string[] goodLevel3 =
    {
        "Critical\nThinking",
        "Evaluate\nInfo",
        "Think Before\nSharing",
        "Reliable\nEvidence"
    };

    private string[] badLevel3 =
    {
        "AI Fake\nImage",
        "Echo\nChamber",
        "Power\nInfluence",
        "Fake\nExpert",
        "Manipulated\nScreenshot"
    };

    void Update()
    {
        timer += Time.deltaTime;

        if (timer >= spawnInterval)
        {
            SpawnItem();
            timer = 0f;
        }
    }

    public void SetDifficulty(int level)
    {
        currentLevel = level;

        if (level == 1)
        {
            spawnInterval = 1.4f;
        }
        else if (level == 2)
        {
            spawnInterval = 1.0f;
        }
        else if (level == 3)
        {
            spawnInterval = 0.7f;
        }
    }

    void SpawnItem()
    {
        float randomX = Random.Range(minX, maxX);
        Vector3 spawnPosition = new Vector3(randomX, spawnY, 0f);

        int badChance;

        if (currentLevel == 1)
        {
            badChance = 25;
        }
        else if (currentLevel == 2)
        {
            badChance = 45;
        }
        else
        {
            badChance = 65;
        }

        int randomNumber = Random.Range(0, 100);
        bool spawnBadItem = randomNumber < badChance;

        GameObject itemToSpawn = spawnBadItem ? badItemPrefab : goodItemPrefab;

        GameObject newItem = Instantiate(itemToSpawn, spawnPosition, Quaternion.identity);

        FallingItem fallingItem = newItem.GetComponent<FallingItem>();

        if (fallingItem != null)
        {
            if (currentLevel == 1)
            {
                fallingItem.fallSpeed = 3f;
            }
            else if (currentLevel == 2)
            {
                fallingItem.fallSpeed = 4.2f;
            }
            else
            {
                fallingItem.fallSpeed = 5.5f;
            }
        }

        CardLabel cardLabel = newItem.GetComponent<CardLabel>();

        if (cardLabel != null)
        {
            if (spawnBadItem)
            {
                cardLabel.SetLabel(GetRandomBadLabel());
            }
            else
            {
                cardLabel.SetLabel(GetRandomGoodLabel());
            }
        }
    }

    string GetRandomGoodLabel()
    {
        if (currentLevel == 1)
        {
            return goodLevel1[Random.Range(0, goodLevel1.Length)];
        }
        else if (currentLevel == 2)
        {
            return goodLevel2[Random.Range(0, goodLevel2.Length)];
        }
        else
        {
            return goodLevel3[Random.Range(0, goodLevel3.Length)];
        }
    }

    string GetRandomBadLabel()
    {
        if (currentLevel == 1)
        {
            return badLevel1[Random.Range(0, badLevel1.Length)];
        }
        else if (currentLevel == 2)
        {
            return badLevel2[Random.Range(0, badLevel2.Length)];
        }
        else
        {
            return badLevel3[Random.Range(0, badLevel3.Length)];
        }
    }
}