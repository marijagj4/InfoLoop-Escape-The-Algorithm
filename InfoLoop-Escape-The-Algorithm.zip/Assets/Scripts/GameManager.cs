using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public int score = 0;
    public int algorithmTrap = 0;
    public int bias = 0;

    public int winScore = 300;
    public int maxTrap = 5;
    public int maxBias = 3;

    public int level1Score = 100;
    public int level2Score = 200;
    public int finalScore = 300;

    public TMP_Text scoreText;
    public TMP_Text trapText;
    public TMP_Text messageText;
    public TMP_Text levelText;
    public TMP_Text biasText;

    public GameObject startPanel;

    public GameObject levelInfoPanel;
    public TMP_Text levelInfoText;
    public Button levelInfoButton;

    public Button restartButton;

    public QuizManager quizManager;
    public ItemSpawner itemSpawner;
    public SoundManager soundManager;

    private bool gameEnded = false;
    private int currentLevel = 1;

    private bool level1QuizDone = false;
    private bool level2QuizDone = false;
    private bool finalQuizDone = false;

    void Start()
    {
        Time.timeScale = 0f;

        score = 0;
        algorithmTrap = 0;
        bias = 0;
        currentLevel = 1;
        gameEnded = false;

        if (startPanel != null)
        {
            startPanel.SetActive(true);
        }

        if (levelInfoPanel != null)
        {
            levelInfoPanel.SetActive(false);
        }

        HideGameHUD();

        if (messageText != null)
        {
            messageText.text = "";
        }

        if (levelInfoButton != null)
        {
            levelInfoButton.onClick.RemoveAllListeners();
            levelInfoButton.onClick.AddListener(StartCurrentLevel);
        }

        if (restartButton != null)
        {
            restartButton.gameObject.SetActive(false);
            restartButton.onClick.RemoveAllListeners();
            restartButton.onClick.AddListener(RestartGame);
        }

        if (soundManager != null)
        {
            soundManager.StopAllMusic();
        }

        UpdateUI();
    }

    public void StartGame()
    {
        if (soundManager != null)
        {
            soundManager.PlayStartSound();
        }

        if (startPanel != null)
        {
            startPanel.SetActive(false);
        }

        ShowLevelInfo(1);
    }

    void ShowLevelInfo(int level)
    {
        Time.timeScale = 0f;

        if (soundManager != null)
        {
            soundManager.StopAllMusic();
        }

        currentLevel = level;
        UpdateUI();

        HideGameHUD();
        ClearFallingItems();

        if (restartButton != null)
        {
            restartButton.gameObject.SetActive(false);
        }

        if (levelInfoPanel != null)
        {
            levelInfoPanel.SetActive(true);
            levelInfoPanel.transform.SetAsLastSibling();
        }

        if (levelInfoText != null)
        {
            if (level == 1)
            {
                levelInfoText.text =
                    "LEVEL 1: CLICKBAIT FEED\n\n" +
                    "Goal:\n" +
                    "Collect reliable information and avoid simple media traps.\n\n" +
                    "Collect:\n" +
                    "- Verified Source\n" +
                    "- Fact Check\n" +
                    "- Date Checked\n\n" +
                    "Avoid:\n" +
                    "- Clickbait Trap\n" +
                    "- Fake News\n" +
                    "- No Date\n\n" +
                    "Reach 100 Score to unlock the first quiz.";
            }
            else if (level == 2)
            {
                levelInfoText.text =
                    "LEVEL 2: BIAS BUBBLE\n\n" +
                    "New mechanic: Bias Meter.\n\n" +
                    "Watch out for:\n" +
                    "- Emotional Manipulation\n" +
                    "- One-sided Story\n" +
                    "- Sponsored Content\n\n" +
                    "These cards increase Bias.\n" +
                    "When Bias reaches 3/3, Algorithm Trap increases by 1.\n\n" +
                    "Collect:\n" +
                    "- Compare Sources\n" +
                    "- Analyze Message\n" +
                    "- Double Check\n\n" +
                    "Reach 200 Score to unlock the second quiz.";
            }
            else if (level == 3)
            {
                levelInfoText.text =
                    "LEVEL 3: AI ALGORITHM STORM\n\n" +
                    "This is the hardest level.\n" +
                    "The feed becomes faster and more dangerous.\n\n" +
                    "Watch out for:\n" +
                    "- AI Fake Image: +2 Algorithm Trap\n" +
                    "- Echo Chamber\n" +
                    "- Fake Expert\n" +
                    "- Manipulated Screenshot\n\n" +
                    "Collect:\n" +
                    "- Critical Thinking\n" +
                    "- Evaluate Info\n" +
                    "- Think Before Sharing\n" +
                    "- Reliable Evidence\n\n" +
                    "Reach 300 Score and complete the final quiz to escape the algorithm.";
            }
        }
    }

    public void StartCurrentLevel()
    {
        if (levelInfoPanel != null)
        {
            levelInfoPanel.SetActive(false);
        }

        ShowGameHUD();

        if (itemSpawner != null)
        {
            itemSpawner.SetDifficulty(currentLevel);
        }

        if (soundManager != null)
        {
            soundManager.PlayGameMusic();
        }

        Time.timeScale = 1f;
    }

    void HideGameHUD()
    {
        if (scoreText != null)
        {
            scoreText.gameObject.SetActive(false);
        }

        if (trapText != null)
        {
            trapText.gameObject.SetActive(false);
        }

        if (levelText != null)
        {
            levelText.gameObject.SetActive(false);
        }

        if (biasText != null)
        {
            biasText.gameObject.SetActive(false);
        }
    }

    void ShowGameHUD()
    {
        if (scoreText != null)
        {
            scoreText.gameObject.SetActive(true);
        }

        if (trapText != null)
        {
            trapText.gameObject.SetActive(true);
        }

        if (levelText != null)
        {
            levelText.gameObject.SetActive(true);
        }

        if (biasText != null)
        {
            biasText.gameObject.SetActive(true);
        }

        UpdateUI();
    }

    void ClearFallingItems()
    {
        FallingItem[] fallingItems = FindObjectsByType<FallingItem>(FindObjectsSortMode.None);

        foreach (FallingItem item in fallingItems)
        {
            Destroy(item.gameObject);
        }
    }

    public void AddScore(int amount)
    {
        if (gameEnded) return;

        score += amount;
        UpdateUI();

        if (score >= level1Score && !level1QuizDone)
        {
            ShowQuiz(0);
            return;
        }

        if (score >= level2Score && !level2QuizDone)
        {
            ShowQuiz(1);
            return;
        }

        if (score >= finalScore && !finalQuizDone)
        {
            ShowQuiz(2);
            return;
        }
    }

    public void AddTrap(int amount)
    {
        if (gameEnded) return;

        algorithmTrap += amount;
        UpdateUI();

        if (algorithmTrap >= maxTrap)
        {
            LoseGame();
        }
    }

    public void AddBias(int amount)
    {
        if (gameEnded) return;

        bias += amount;

        if (bias >= maxBias)
        {
            bias = 0;
            algorithmTrap += 1;
            Debug.Log("Bias bubble created an Algorithm Trap!");
        }

        UpdateUI();

        if (algorithmTrap >= maxTrap)
        {
            LoseGame();
        }
    }

    public void ReduceTrap(int amount)
    {
        algorithmTrap -= amount;

        if (algorithmTrap < 0)
        {
            algorithmTrap = 0;
        }

        UpdateUI();
    }

    void ShowQuiz(int quizIndex)
    {
        Time.timeScale = 0f;

        if (soundManager != null)
        {
            soundManager.PlayQuizMusic();
        }

        HideGameHUD();
        ClearFallingItems();

        if (startPanel != null)
        {
            startPanel.SetActive(false);
        }

        if (levelInfoPanel != null)
        {
            levelInfoPanel.SetActive(false);
        }

        if (restartButton != null)
        {
            restartButton.gameObject.SetActive(false);
        }

        if (quizManager != null)
        {
            quizManager.ShowQuiz(quizIndex);
            Debug.Log("GameManager opened quiz: " + quizIndex);
        }
        else
        {
            Debug.LogError("QuizManager is not connected in GameManager!");
        }
    }

    public void FinishQuiz(int quizIndex, bool correct)
    {
        if (soundManager != null)
        {
            soundManager.StopQuizMusic();
        }

        if (correct)
        {
            score += 20;
            ReduceTrap(1);
        }
        else
        {
            algorithmTrap += 1;
        }

        if (algorithmTrap >= maxTrap)
        {
            UpdateUI();
            LoseGame();
            return;
        }

        if (quizIndex == 0)
        {
            level1QuizDone = true;
            ShowLevelInfo(2);
        }
        else if (quizIndex == 1)
        {
            level2QuizDone = true;
            ShowLevelInfo(3);
        }
        else if (quizIndex == 2)
        {
            finalQuizDone = true;

            if (correct)
            {
                WinGame();
            }
            else
            {
                LoseGame();
            }
        }

        UpdateUI();
    }

    void UpdateUI()
    {
        if (scoreText != null)
        {
            scoreText.text = "Score: " + score;
        }

        if (trapText != null)
        {
            trapText.text = "Algorithm Trap: " + algorithmTrap;
        }

        if (biasText != null)
        {
            biasText.text = "Bias: " + bias + "/" + maxBias;
        }

        if (levelText != null)
        {
            if (currentLevel == 1)
            {
                levelText.text = "Level 1: Clickbait Feed";
            }
            else if (currentLevel == 2)
            {
                levelText.text = "Level 2: Bias Bubble";
            }
            else if (currentLevel == 3)
            {
                levelText.text = "Level 3: AI Algorithm Storm";
            }
        }
    }

    void WinGame()
    {
        gameEnded = true;

        if (soundManager != null)
        {
            soundManager.StopAllMusic();
        }

        HideGameHUD();
        ClearFallingItems();

        if (messageText != null)
        {
            messageText.text = "You escaped the algorithm!\nYou analyzed, evaluated and shared information responsibly.";
            messageText.gameObject.SetActive(true);
        }

        if (restartButton != null)
        {
            restartButton.gameObject.SetActive(true);
            restartButton.transform.SetAsLastSibling();
        }

        Time.timeScale = 0f;
    }

    void LoseGame()
    {
        gameEnded = true;

        if (soundManager != null)
        {
            soundManager.StopAllMusic();
        }

        HideGameHUD();
        ClearFallingItems();

        if (messageText != null)
        {
            messageText.text = "The algorithm trapped you!\nToo much bias, clickbait and unreliable content took over your feed.";
            messageText.gameObject.SetActive(true);
        }

        if (restartButton != null)
        {
            restartButton.gameObject.SetActive(true);
            restartButton.transform.SetAsLastSibling();
        }

        Time.timeScale = 0f;
    }

    public void RestartGame()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}