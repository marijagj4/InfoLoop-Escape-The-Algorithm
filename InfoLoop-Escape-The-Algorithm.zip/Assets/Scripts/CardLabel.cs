using UnityEngine;
using TMPro;

public class CardLabel : MonoBehaviour
{
    public TMP_Text labelText;
    public string currentLabel;

    public void SetLabel(string text)
    {
        currentLabel = text;

        if (labelText != null)
        {
            labelText.text = text;
        }
    }
}