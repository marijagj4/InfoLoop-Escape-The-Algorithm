using UnityEngine;

public class FallingItem : MonoBehaviour
{
    public float fallSpeed = 2f;
    public float bottomLimit = -4.5f;

    void Update()
    {
        transform.position += Vector3.down * fallSpeed * Time.deltaTime;

        if (transform.position.y < bottomLimit)
        {
            Destroy(gameObject);
        }
    }
}