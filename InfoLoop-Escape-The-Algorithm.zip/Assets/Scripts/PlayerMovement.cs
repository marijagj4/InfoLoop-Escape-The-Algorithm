using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float speed = 6f;
    public float limitX = 7.5f;
    public float limitY = 4f;

    void Update()
    {
        float moveX = 0f;
        float moveY = 0f;

        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
        {
            moveX = -1f;
        }

        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
        {
            moveX = 1f;
        }

        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))
        {
            moveY = 1f;
        }

        if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))
        {
            moveY = -1f;
        }

        Vector3 movement = new Vector3(moveX, moveY, 0f).normalized;

        transform.position += movement * speed * Time.deltaTime;

        float clampedX = Mathf.Clamp(transform.position.x, -limitX, limitX);
        float clampedY = Mathf.Clamp(transform.position.y, -limitY, limitY);

        transform.position = new Vector3(clampedX, clampedY, transform.position.z);
    }
}