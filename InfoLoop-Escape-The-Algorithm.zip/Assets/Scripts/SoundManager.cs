using UnityEngine;

public class SoundManager : MonoBehaviour
{
    private AudioSource effectsSource;
    private AudioSource gameMusicSource;
    private AudioSource quizMusicSource;

    private AudioClip goodClip;
    private AudioClip badClip;
    private AudioClip specialClip;
    private AudioClip startClip;

    private AudioClip gameMusic;
    private AudioClip quizMusic;

    void Awake()
    {
        AudioSource[] sources = GetComponents<AudioSource>();

        if (sources.Length < 3)
        {
            while (GetComponents<AudioSource>().Length < 3)
            {
                gameObject.AddComponent<AudioSource>();
            }

            sources = GetComponents<AudioSource>();
        }

        effectsSource = sources[0];
        gameMusicSource = sources[1];
        quizMusicSource = sources[2];

        effectsSource.playOnAwake = false;
        effectsSource.volume = 1f;

        gameMusicSource.playOnAwake = false;
        gameMusicSource.loop = true;
        gameMusicSource.volume = 0.22f;

        quizMusicSource.playOnAwake = false;
        quizMusicSource.loop = true;
        quizMusicSource.volume = 0.24f;

        goodClip = CreateTone(900f, 0.13f, 0.5f);
        badClip = CreateTone(130f, 0.25f, 0.55f);
        specialClip = CreateTone(1300f, 0.20f, 0.55f);
        startClip = CreateStartSound();

        gameMusic = CreateGameMusic();
        quizMusic = CreateQuizMusic();

        gameMusicSource.clip = gameMusic;
        quizMusicSource.clip = quizMusic;
    }

    public void PlayStartSound()
    {
        effectsSource.PlayOneShot(startClip, 0.9f);
    }

    public void PlayGoodSound()
    {
        effectsSource.PlayOneShot(goodClip, 0.9f);
    }

    public void PlayBadSound()
    {
        effectsSource.PlayOneShot(badClip, 1f);
    }

    public void PlaySpecialSound()
    {
        effectsSource.PlayOneShot(specialClip, 1f);
    }

    public void PlayGameMusic()
    {
        StopQuizMusic();

        if (!gameMusicSource.isPlaying)
        {
            gameMusicSource.Play();
        }
    }

    public void StopGameMusic()
    {
        gameMusicSource.Stop();
    }

    public void PlayQuizMusic()
    {
        StopGameMusic();

        if (!quizMusicSource.isPlaying)
        {
            quizMusicSource.Play();
        }
    }

    public void StopQuizMusic()
    {
        quizMusicSource.Stop();
    }

    public void StopAllMusic()
    {
        StopGameMusic();
        StopQuizMusic();
    }

    AudioClip CreateTone(float frequency, float duration, float volume)
    {
        int sampleRate = 44100;
        int sampleLength = Mathf.RoundToInt(sampleRate * duration);
        float[] samples = new float[sampleLength];

        for (int i = 0; i < sampleLength; i++)
        {
            float time = (float)i / sampleRate;
            float fade = 1f - (time / duration);
            samples[i] = Mathf.Sin(2f * Mathf.PI * frequency * time) * volume * fade;
        }

        AudioClip clip = AudioClip.Create("Tone", sampleLength, 1, sampleRate, false);
        clip.SetData(samples, 0);

        return clip;
    }

    AudioClip CreateStartSound()
    {
        int sampleRate = 44100;
        float duration = 0.45f;
        int sampleLength = Mathf.RoundToInt(sampleRate * duration);
        float[] samples = new float[sampleLength];

        for (int i = 0; i < sampleLength; i++)
        {
            float time = (float)i / sampleRate;

            float frequency;

            if (time < 0.12f)
            {
                frequency = 523f;
            }
            else if (time < 0.24f)
            {
                frequency = 659f;
            }
            else if (time < 0.36f)
            {
                frequency = 784f;
            }
            else
            {
                frequency = 1046f;
            }

            float fade = 1f - (time / duration);
            samples[i] = Mathf.Sin(2f * Mathf.PI * frequency * time) * 0.45f * fade;
        }

        AudioClip clip = AudioClip.Create("StartSound", sampleLength, 1, sampleRate, false);
        clip.SetData(samples, 0);

        return clip;
    }

    AudioClip CreateGameMusic()
    {
        int sampleRate = 44100;
        float duration = 8f;
        int sampleLength = Mathf.RoundToInt(sampleRate * duration);
        float[] samples = new float[sampleLength];

        float[] melody = { 262f, 330f, 392f, 330f, 294f, 349f, 440f, 349f };
        float[] bass = { 131f, 131f, 147f, 147f, 165f, 165f, 147f, 147f };

        for (int i = 0; i < sampleLength; i++)
        {
            float time = (float)i / sampleRate;

            int melodyIndex = Mathf.FloorToInt(time * 3f) % melody.Length;
            int bassIndex = Mathf.FloorToInt(time * 1.5f) % bass.Length;

            float melodyFreq = melody[melodyIndex];
            float bassFreq = bass[bassIndex];

            float beat = Mathf.FloorToInt(time * 6f) % 2 == 0 ? 1f : 0.65f;

            float melodyWave = Mathf.Sin(2f * Mathf.PI * melodyFreq * time) * 0.16f;
            float harmonyWave = Mathf.Sin(2f * Mathf.PI * melodyFreq * 1.5f * time) * 0.05f;
            float bassWave = Mathf.Sin(2f * Mathf.PI * bassFreq * time) * 0.10f;

            samples[i] = (melodyWave + harmonyWave + bassWave) * beat;
        }

        AudioClip clip = AudioClip.Create("GameMusic", sampleLength, 1, sampleRate, false);
        clip.SetData(samples, 0);

        return clip;
    }

    AudioClip CreateQuizMusic()
    {
        int sampleRate = 44100;
        float duration = 6f;
        int sampleLength = Mathf.RoundToInt(sampleRate * duration);
        float[] samples = new float[sampleLength];

        float[] notes = { 392f, 370f, 392f, 440f, 392f, 330f, 349f, 392f };

        for (int i = 0; i < sampleLength; i++)
        {
            float time = (float)i / sampleRate;

            int noteIndex = Mathf.FloorToInt(time * 4f) % notes.Length;
            float frequency = notes[noteIndex];

            float pulse = Mathf.Sin(2f * Mathf.PI * 2f * time) * 0.5f + 0.5f;

            float wave1 = Mathf.Sin(2f * Mathf.PI * frequency * time) * 0.15f;
            float wave2 = Mathf.Sin(2f * Mathf.PI * frequency * 0.5f * time) * 0.08f;
            float tension = Mathf.Sin(2f * Mathf.PI * 110f * time) * 0.04f;

            samples[i] = (wave1 + wave2 + tension) * (0.65f + pulse * 0.35f);
        }

        AudioClip clip = AudioClip.Create("QuizMusic", sampleLength, 1, sampleRate, false);
        clip.SetData(samples, 0);

        return clip;
    }
}