using UnityEngine;

public class GoodItemCollect : MonoBehaviour
{
    public int points = 10;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            GameManager gameManager = FindFirstObjectByType<GameManager>();
            SoundManager soundManager = FindFirstObjectByType<SoundManager>();
            CardLabel cardLabel = GetComponent<CardLabel>();

            string label = "";

            if (cardLabel != null)
            {
                label = cardLabel.currentLabel;
            }

            if (gameManager != null)
            {
                if (label.Contains("Think Before") || label.Contains("Double"))
                {
                    gameManager.AddScore(20);
                    gameManager.ReduceTrap(1);

                    if (soundManager != null)
                    {
                        soundManager.PlaySpecialSound();
                    }

                    Debug.Log("Special good card collected: " + label);
                }
                else
                {
                    gameManager.AddScore(points);

                    if (soundManager != null)
                    {
                        soundManager.PlayGoodSound();
                    }

                    Debug.Log("Good card collected: " + label);
                }
            }

            Destroy(gameObject);
        }
    }
}